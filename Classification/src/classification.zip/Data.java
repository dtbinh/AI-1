import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Data {
//	HashMap<Integer, ArrayList<String>> other;
//	HashMap<Integer, ArrayList<String>> row;
//	
//	HashMap<Integer, ArrayList<String>> testRow;
//	HashMap<Integer, ArrayList<String>> testOther;
	Jama.Matrix meanType;
	Jama.Matrix variance;
	HashMap<Integer, Jama.Matrix> row;	
	HashMap<Integer, ArrayList<String>> other;
	
	HashMap<Integer, Jama.Matrix> testRow;
	HashMap<Integer, ArrayList<String>> testOther;
	int classType = 0;
	int dDimension = 0;
	
	public void setMean(Jama.Matrix aMatrix){
		meanType = new Jama.Matrix(aMatrix.getRowDimension(),aMatrix.getColumnDimension());
		meanType = aMatrix;
	}
	
	public void setVariance(Jama.Matrix aMatrix){
		variance = new Jama.Matrix(aMatrix.getRowDimension(),aMatrix.getColumnDimension());
		variance = aMatrix;
	}
	public Data(){
		testOther = new HashMap<Integer,ArrayList<String>>();
		testRow = new HashMap<Integer,Jama.Matrix>();
		other = new HashMap<Integer,ArrayList<String>>();
		row = new HashMap<Integer,Jama.Matrix>();
	}
	public Data(String fileName, int type){
		classType = type;
		String DfileName = fileName;//"zoo.csv";
		File file = new File(DfileName);
		
		try {
//			avoid  = new ArrayList<Integer>();
			Scanner inputStream = new Scanner(file);
			int j = 0;int jj =0; int totalRow = 0; 
			other = new HashMap<Integer,ArrayList<String>>();
			testOther = new HashMap<Integer,ArrayList<String>>();
			row = new HashMap<Integer,Jama.Matrix>();
			testRow = new HashMap<Integer,Jama.Matrix>();
			int testing = 0; 
			while(inputStream.hasNext()){
				
				String data = inputStream.next(); // return next thing
				String[] value = data.split(",");
				int size = value.length - 1;
//				if(value[size].equals(type)){
				if(value[0].equals(type+"")){
					ArrayList<String> columns = new ArrayList<String>();
					ArrayList<String> otherColumns = new ArrayList<String>();
					for(int i =0;i<value.length;i++){
//						if(isInteger(value[i])&& i != (value.length-1)){
						if(isInteger(value[i])&& i != 0){
							columns.add(value[i]);
//							System.out.print(value[i] + " ***");
						}else{
							otherColumns.add(value[i]);
//							System.out.print(value[i] + " *O*");
						}
					}
					Jama.Matrix xVector = new Jama.Matrix(columns.size(),1);
					dDimension = columns.size();
					for(int ii=0;ii<columns.size();ii++){
						xVector.set(ii, 0,Double.parseDouble(columns.get(ii)));
					}
//					if(testing%10 ==0&& setup.equals("FOLD")){
////						System.out.println("testrow");
//						testRow.put(j, xVector);
//						testOther.put(j, otherColumns);
//						j++;
//					}else if(classificationType.equals("oneVector")){
//						testRow.put(j, xVector);
//						testOther.put(j, otherColumns);
//						j++;
//						classificationType = "";
//					}else{
						row.put(jj, xVector);
						other.put(jj, otherColumns);
						jj++;
//					}
					testing++;
				}
			}
			inputStream.close();
			System.out.println("row " + row.get(0));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static boolean isInteger(String s) {
		if(s.isEmpty()) return false;
		for(int i = 0; i < s.length(); i++) {
	        if(s.charAt(i)== '0' || s.charAt(i)== '1' ||s.charAt(i)== '2' ||s.charAt(i)== '3' ||s.charAt(i)== '4' ||s.charAt(i)== '5' ||
	        		s.charAt(i)== '6' ||s.charAt(i)== '7' ||s.charAt(i)== '8' ||s.charAt(i)== '9' ||s.charAt(i)== '.') {
	            
	        }else{
	        	return false;
	        }
	    }
	    return true;
	}
}
